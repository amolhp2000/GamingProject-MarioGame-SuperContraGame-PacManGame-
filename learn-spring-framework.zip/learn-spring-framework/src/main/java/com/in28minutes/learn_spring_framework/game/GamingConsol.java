package com.in28minutes.learn_spring_framework.game;

public interface GamingConsol {

	void up();
	void down();
	void left();
	void right();
	
}
