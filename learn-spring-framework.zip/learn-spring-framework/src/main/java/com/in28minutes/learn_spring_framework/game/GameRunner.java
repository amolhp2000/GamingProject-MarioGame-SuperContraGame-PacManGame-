package com.in28minutes.learn_spring_framework.game;

public class GameRunner {

	// Iteration 1: Tightly Couple Java code
	
//	private MarioGame game;
	
//	public GameRunner(MarioGame game) {
//		super();
//		this.game = game;
//	}

	//SuperContra Game
	
//	private SuperContra game;
//	public  GameRunner(SuperContra game) {
//		this.game = game;
//	}
	
	// Iteration 2: Loosely Couple Java code using interface
	
	private GamingConsol game;
	
	
	public GameRunner(GamingConsol game) {
		super();
		this.game = game;
	}


	public void run() {
		System.out.println("Running a Game " + game);
		game.up();
		game.down();
		game.left();
		game.right();
		
	}
	
}
