package com.in28minutes.learn_spring_framework;

import com.in28minutes.learn_spring_framework.game.GameRunner;
import com.in28minutes.learn_spring_framework.game.MarioGame;
import com.in28minutes.learn_spring_framework.game.PacManGame;
import com.in28minutes.learn_spring_framework.game.SuperContraGame;

public class AppGamingBasic {

	public static void main(String[] args) {
		
		// Iteration 1: Tightly Couple Java code 
		
//		var marioGame = new MarioGame();
//		var gameRunner = new GameRunner(marioGame);
//		gameRunner.run();
		
//		var superContra = new SuperContra();
//		var gameRunner = new GameRunner(superContra);
//		gameRunner.run();

		
		// Iteration 2: Loosely Couple Java code using interface(whichever game you want to run just uncomment it and run it no need to code change...
		//var game = new MarioGame();
		//var game = new SuperContra();
		var game = new PacManGame();
		
		var gamRunner = new GameRunner(game);
		gamRunner.run();
		
	}

}
