package com.in28minutes.learn_spring_framework.game;

public class MarioGame implements GamingConsol {
	
	public void up()
	{
		System.out.println("Jump");
	}
	
	public void down()
	{
		System.out.println("Going in to holl");
	}
	
	public void left()
	{
		System.out.println("Going to back..");
	}
	
	public void right()
	{
		System.out.println("Accelarate..");
	}
}
